import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <>
    <div className="App">
      <h1>Hello Dojo!!</h1>
      <h3>Things I need to do</h3>
        <ul>
          <li>Learn React</li>
          <li>Finish my Resume</li>
          <li>Complete 2 projects</li>
          <li>Not shoot myself</li>
        </ul>      
    </div>
    </>
  );
}

export default App;
